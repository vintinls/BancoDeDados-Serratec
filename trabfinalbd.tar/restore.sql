--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: trab; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA trab;


ALTER SCHEMA trab OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: delegacia; Type: TABLE; Schema: trab; Owner: postgres
--

CREATE TABLE trab.delegacia (
    del_cd_id integer NOT NULL,
    del_tx_telefone character varying(13),
    del_dt_dtdenuncia date,
    del_int_identificacao_delegacia integer,
    del_tx_oficialquerecebeu character varying(30),
    del_tx_estadodadelegacia character varying(20),
    fk_del_end integer,
    fk_del_den integer
);


ALTER TABLE trab.delegacia OWNER TO postgres;

--
-- Name: delegacia_del_cd_id_seq; Type: SEQUENCE; Schema: trab; Owner: postgres
--

CREATE SEQUENCE trab.delegacia_del_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trab.delegacia_del_cd_id_seq OWNER TO postgres;

--
-- Name: delegacia_del_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: trab; Owner: postgres
--

ALTER SEQUENCE trab.delegacia_del_cd_id_seq OWNED BY trab.delegacia.del_cd_id;


--
-- Name: denuncia; Type: TABLE; Schema: trab; Owner: postgres
--

CREATE TABLE trab.denuncia (
    den_cd_id integer NOT NULL,
    den_tx_tipo_denuncia character varying(200),
    den_dt_dtocorrencia date,
    den_tx_descricao character varying(200),
    den_tx_testemunhas character varying(200),
    den_tx_evidencias character varying(10),
    fk_den_usu integer
);


ALTER TABLE trab.denuncia OWNER TO postgres;

--
-- Name: denuncia_den_cd_id_seq; Type: SEQUENCE; Schema: trab; Owner: postgres
--

CREATE SEQUENCE trab.denuncia_den_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trab.denuncia_den_cd_id_seq OWNER TO postgres;

--
-- Name: denuncia_den_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: trab; Owner: postgres
--

ALTER SEQUENCE trab.denuncia_den_cd_id_seq OWNED BY trab.denuncia.den_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: trab; Owner: postgres
--

CREATE TABLE trab.endereco (
    end_cd_id integer NOT NULL,
    end_tx_estado character varying(30),
    end_tx_cidade character varying(30),
    end_tx_bairro character varying(30),
    end_tx_rua character varying(50),
    end_tx_complemento character varying(10)
);


ALTER TABLE trab.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE; Schema: trab; Owner: postgres
--

CREATE SEQUENCE trab.endereco_end_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trab.endereco_end_cd_id_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: trab; Owner: postgres
--

ALTER SEQUENCE trab.endereco_end_cd_id_seq OWNED BY trab.endereco.end_cd_id;


--
-- Name: usuario; Type: TABLE; Schema: trab; Owner: postgres
--

CREATE TABLE trab.usuario (
    usu_cd_id integer NOT NULL,
    usu_tx_nome_completo character varying(100),
    usu_tx_cpf character varying(14),
    usu_tx_telefone character varying(13),
    usu_tx_email character varying(100),
    usu_tx_genero character varying(20),
    fk_usu_end integer
);


ALTER TABLE trab.usuario OWNER TO postgres;

--
-- Name: usuario_usu_cd_id_seq; Type: SEQUENCE; Schema: trab; Owner: postgres
--

CREATE SEQUENCE trab.usuario_usu_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE trab.usuario_usu_cd_id_seq OWNER TO postgres;

--
-- Name: usuario_usu_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: trab; Owner: postgres
--

ALTER SEQUENCE trab.usuario_usu_cd_id_seq OWNED BY trab.usuario.usu_cd_id;


--
-- Name: delegacia del_cd_id; Type: DEFAULT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.delegacia ALTER COLUMN del_cd_id SET DEFAULT nextval('trab.delegacia_del_cd_id_seq'::regclass);


--
-- Name: denuncia den_cd_id; Type: DEFAULT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.denuncia ALTER COLUMN den_cd_id SET DEFAULT nextval('trab.denuncia_den_cd_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('trab.endereco_end_cd_id_seq'::regclass);


--
-- Name: usuario usu_cd_id; Type: DEFAULT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.usuario ALTER COLUMN usu_cd_id SET DEFAULT nextval('trab.usuario_usu_cd_id_seq'::regclass);


--
-- Data for Name: delegacia; Type: TABLE DATA; Schema: trab; Owner: postgres
--

COPY trab.delegacia (del_cd_id, del_tx_telefone, del_dt_dtdenuncia, del_int_identificacao_delegacia, del_tx_oficialquerecebeu, del_tx_estadodadelegacia, fk_del_end, fk_del_den) FROM stdin;
\.
COPY trab.delegacia (del_cd_id, del_tx_telefone, del_dt_dtdenuncia, del_int_identificacao_delegacia, del_tx_oficialquerecebeu, del_tx_estadodadelegacia, fk_del_end, fk_del_den) FROM '$$PATH$$/4870.dat';

--
-- Data for Name: denuncia; Type: TABLE DATA; Schema: trab; Owner: postgres
--

COPY trab.denuncia (den_cd_id, den_tx_tipo_denuncia, den_dt_dtocorrencia, den_tx_descricao, den_tx_testemunhas, den_tx_evidencias, fk_den_usu) FROM stdin;
\.
COPY trab.denuncia (den_cd_id, den_tx_tipo_denuncia, den_dt_dtocorrencia, den_tx_descricao, den_tx_testemunhas, den_tx_evidencias, fk_den_usu) FROM '$$PATH$$/4868.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: trab; Owner: postgres
--

COPY trab.endereco (end_cd_id, end_tx_estado, end_tx_cidade, end_tx_bairro, end_tx_rua, end_tx_complemento) FROM stdin;
\.
COPY trab.endereco (end_cd_id, end_tx_estado, end_tx_cidade, end_tx_bairro, end_tx_rua, end_tx_complemento) FROM '$$PATH$$/4864.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: trab; Owner: postgres
--

COPY trab.usuario (usu_cd_id, usu_tx_nome_completo, usu_tx_cpf, usu_tx_telefone, usu_tx_email, usu_tx_genero, fk_usu_end) FROM stdin;
\.
COPY trab.usuario (usu_cd_id, usu_tx_nome_completo, usu_tx_cpf, usu_tx_telefone, usu_tx_email, usu_tx_genero, fk_usu_end) FROM '$$PATH$$/4866.dat';

--
-- Name: delegacia_del_cd_id_seq; Type: SEQUENCE SET; Schema: trab; Owner: postgres
--

SELECT pg_catalog.setval('trab.delegacia_del_cd_id_seq', 5, true);


--
-- Name: denuncia_den_cd_id_seq; Type: SEQUENCE SET; Schema: trab; Owner: postgres
--

SELECT pg_catalog.setval('trab.denuncia_den_cd_id_seq', 5, true);


--
-- Name: endereco_end_cd_id_seq; Type: SEQUENCE SET; Schema: trab; Owner: postgres
--

SELECT pg_catalog.setval('trab.endereco_end_cd_id_seq', 6, true);


--
-- Name: usuario_usu_cd_id_seq; Type: SEQUENCE SET; Schema: trab; Owner: postgres
--

SELECT pg_catalog.setval('trab.usuario_usu_cd_id_seq', 5, true);


--
-- Name: delegacia delegacia_pkey; Type: CONSTRAINT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.delegacia
    ADD CONSTRAINT delegacia_pkey PRIMARY KEY (del_cd_id);


--
-- Name: denuncia denuncia_pkey; Type: CONSTRAINT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.denuncia
    ADD CONSTRAINT denuncia_pkey PRIMARY KEY (den_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usu_cd_id);


--
-- Name: delegacia fk_del_den; Type: FK CONSTRAINT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.delegacia
    ADD CONSTRAINT fk_del_den FOREIGN KEY (fk_del_den) REFERENCES trab.denuncia(den_cd_id);


--
-- Name: delegacia fk_del_end; Type: FK CONSTRAINT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.delegacia
    ADD CONSTRAINT fk_del_end FOREIGN KEY (fk_del_end) REFERENCES trab.endereco(end_cd_id);


--
-- Name: denuncia fk_den_usu; Type: FK CONSTRAINT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.denuncia
    ADD CONSTRAINT fk_den_usu FOREIGN KEY (fk_den_usu) REFERENCES trab.usuario(usu_cd_id);


--
-- Name: usuario fk_usu_end; Type: FK CONSTRAINT; Schema: trab; Owner: postgres
--

ALTER TABLE ONLY trab.usuario
    ADD CONSTRAINT fk_usu_end FOREIGN KEY (fk_usu_end) REFERENCES trab.endereco(end_cd_id);


--
-- PostgreSQL database dump complete
--

